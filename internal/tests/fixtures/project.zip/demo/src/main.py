from .store import save
def run():
    return save()
